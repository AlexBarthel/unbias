console.log("================================");
console.log("Injected contentScript.js");
console.log("================================");

function getRawContent() {
    const textList = Array.from(document.getElementsByTagName("p"));
    return textList.map(e => e.textContent).join("");
}

function createArcPath(d, strokeColor) {
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("d", d);
    path.style.fill = "none";
    path.style.stroke = strokeColor;
    path.style.strokeWidth = "20";
    return path;
}

async function createSummaryModal(score) {
    let modalOverlay = document.createElement("div");
    modalOverlay.className = "bg-modal-overlay";
    Object.assign(modalOverlay.style, {
        position: "fixed",
        top: "0",
        left: "0",
        width: "100%",
        height: "100%",
        zIndex: "99999",
        backgroundColor: "rgba(0,0,0,0.5)",
        opacity: "0",
        transition: "opacity 500ms"
    });

    let modal = document.createElement("div");
    modal.className = "bg-modal";
    Object.assign(modal.style, {
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, 50%)",
        opacity: "0",
        backgroundColor: "#121212",
        borderRadius: ".5rem",
        zIndex: "99999",
        width: "fit-content",
        height: "fit-content",
        padding: "2.5rem",
        display: "grid",
        placeItems: "center",
        transition: "transform 1s, opacity 1s"
    });

    let meterContainer = document.createElement("div");
    meterContainer.className = "unbias-meter";
    meterContainer.style.position = "relative";

    const meter = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    meter.setAttribute("viewBox", "0 0 200 100");
    meter.setAttribute("width", "200");
    meter.setAttribute("height", "100");
    meter.classList.add("unbias-meter__arc");
    meter.style.opacity = "0";
    meter.style.transition = "opacity 500ms";

    const leftArc = createArcPath("M 20 100 A 90 90 0 0 1 70 20", "#4763ff");
    const centerArc = createArcPath("M 70 20 A 70 70 0 0 1 130 20", "#a467ff");
    const rightArc = createArcPath("M 130 20 A 90 90 0 0 1 180 100", "#ff6347");

    meter.append(leftArc, centerArc, rightArc);
    meterContainer.appendChild(meter);

    const arrow = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
    arrow.setAttribute("points", "95,28 105,28 100,18");
    arrow.style.fill = "#fff";
    arrow.style.transformOrigin = "100px 80px";
    arrow.style.transition = "transform 1s ease, opacity 1s ease";
    arrow.style.opacity = "0";

    const label = document.createElementNS("http://www.w3.org/2000/svg", "text");
    label.setAttribute("x", "100");
    label.setAttribute("y", "80");
    label.setAttribute("text-anchor", "middle");
    label.setAttribute("font-size", "1.5rem");
    label.setAttribute("fill", "#fff");
    label.style.opacity = "0";
    label.textContent = score.toFixed(1);

    const biasLabel = document.createElement("p");
    Object.assign(biasLabel.style, {
        color: "#dedede",
        fontSize: ".75rem",
        fontFamily: "system-ui",
        opacity: "0",
        transiton: "opacity 500ms"
    });
    biasLabel.textContent = score <= -0.8 ? "LEFT" : score <= -0.3 ? "LEFT-LEANING" : score >= 0.8 ? "RIGHT" : score >= 0.3 ? "RIGHT-LEANING" : "CENTER";

    const close = document.createElement("button");
    Object.assign(close.style, {
        background: "none",
        color: "#fff",
        border: "2px solid #4763ff",
        borderRadius: ".2rem",
        padding: ".5rem 3rem",
        marginTop: "1.5rem",
        cursor: "pointer",
        transition: "background 200ms, opacity 1s",
        opacity: "0"
    });
    close.textContent = "Close";

    meter.append(arrow, label);
    modal.append(meterContainer, biasLabel, close);
    modalOverlay.appendChild(modal);
    document.body.appendChild(modalOverlay);

    await delay(500);
    modalOverlay.style.opacity = "1";
    await delay(500);
    modal.style.opacity = "1";
    modal.style.transform = "translate(-50%, -50%)";
    await delay(1000);
    meter.style.opacity = "1";
    await delay(100);
    arrow.style.transform = `rotate(${score * 90}deg)`;
    arrow.style.opacity = "1";
    label.style.opacity = "1";
    await delay(100);
    biasLabel.style.opacity = "1";
    await delay(100);
    close.style.opacity = "1";

    close.onmouseover = () => close.style.background = "#4763ff";
    close.onmouseleave = () => close.style.background = "none";
    close.onclick = () => {
        modalOverlay.style.opacity = "0";
        setTimeout(() => modalOverlay.style.display = "none", 500);
    };
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function createResponseBlock(name, reason, alignment) {
    let el = document.createElement("div");
    Object.assign(el.style, {
        position: "relative",
        display: "flex",
        alignItems: "center",
        background: "#121212",
        padding: ".25rem .5rem",
        borderRadius: ".5rem",
        marginBottom: ".5rem"
    })

    let title = document.createElement("p");
    Object.assign(title.style, {
        fontFamily: "system-ui",
        margin: "0",
        padding: "0",
        fontSize: ".8rem",
        fontWeight: "normal",
        marginLeft: ".5rem",
        userSelect: "none",
        color: "#fff"
    })
    title.innerText = name;

    let color = document.createElement("span");
    Object.assign(color.style, {
        backgroundColor: alignment === "left" ? "#4763ff" : alignment === "right" ? "#ff6347" : "#a467ff",
        width: ".8rem",
        height: ".8rem",
        borderRadius: "50%"
    })

    el.appendChild(color);
    el.appendChild(title);

    let container = document.createElement("div");
    Object.assign(container.style, {
        zIndex: "9999",
        position: "absolute",
        left: "0",
        bottom: "0",
        transform: "translateY(100%)",
        width: "16rem",
        height: "fit-content",
        display: "none",
        backgroundColor: "#121212",
        borderRadius: "0 .5rem .5rem .5rem"
    });

    let text = document.createElement("p");
    Object.assign(text.style, {
        padding: ".5rem",
        margin: "0",
        fontFamily: "system-ui",
        fontSize: ".8rem",
        lineHeight: "1.6",
        fontWeight: "normal",
        color: "#fff"
    });
    text.innerText = reason;

    container.appendChild(text);
    el.appendChild(container);

    el.addEventListener("mouseenter", () => {
        el.style.borderRadius = "0.5rem 0.5rem 0 0";
        container.style.display = "block";
    });
    el.addEventListener("mouseleave", () => {
        el.style.borderRadius = "0.5rem";
        container.style.display = "none";
    });

    return el;
}

function highlightBiases(responses) {
    const text = document.getElementsByTagName("p");
    const textList = Array.prototype.slice.call(text);

    let biasScore = 0;

    responses.forEach(model => {
        model.biases.forEach(b => {
            let text = b.text;
            let alignment = b.alignment;
            let reason = b.reason;
            for (el of textList) {
                if (el.innerHTML.indexOf(text) !== -1) {
                    let Responses = document.createElement("div");
                    Responses.style.display = "flex";

                    let responseBlock = createResponseBlock(model.name, reason, alignment);

                    biasScore += (alignment === "left") ? -1 / model.biases.length : (alignment === "right") ? 1 / model.biases.length : 0;

                    Responses.appendChild(responseBlock);
                    el.appendChild(Responses);
                }
            }
        })
    })

    createSummaryModal(biasScore);
}

chrome.runtime.onMessage.addListener(async (request, sender, sendResponse) => {
    switch (request.action) {
        case "get-raw-content":
            sendResponse({ content: getRawContent() });
            break;
        case "highlight-biases":
            highlightBiases(JSON.parse(request.data));
            break;
    }
});