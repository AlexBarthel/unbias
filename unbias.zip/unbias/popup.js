// chrome.tabs.query({ active: true }, function (tabs) {
//     let tab = tabs[0];
//     chrome.scripting.executeScript({
//         target: { tabId: tab.id },
//         function: getElements,
//     }, getResults);
// });

// chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
//     chrome.tabs.sendMessage(tabs[0].id, {
//         action: "allowPaste"
//     });
// });

let models = [
    {
        name: "Gemini (with 1.5 Flash)",
        url: "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyDAwQc1AMR_JC4uouVRLvTpmMv2-1gqLMM",
        params: {
            method: "post",
            headers: {
                "Content-Type": "application/json",
            },
        },
        getContent: (text) => {
            return JSON.parse(text).candidates[0].content.parts[0].text;
        },
    },
    {
        name: "ChatGPT 4o mini",
        url: "",
        params: {
            method: "post",
            headers: {
                "Content-Type": "application/json",
            },
        },
        getContent: (res) => { },
    },
    {
        name: "Grok-1",
        url: "",
        params: {
            method: "post",
            headers: {
                "Content-Type": "application/json",
            },
        },
        getContent: (res) => { },
    },
];
// let systemInstructions = `Identify any biases within the following text, and format them as an array of objects like so: [{"text": "...", "alignment": "left/right/center", "reason": "..."}, ...]. Do not format using markdown, and do not include any other text except the plaintext array in your response. Make sure to escape any characters that would invalidate JSON. Keep responses as short as possible, preferably one or two sentences. Here is your data: `;
let systemInstructions = `Find any political biases in the provided text. When responding, do not include any other text except a plaintext array formatted like so: [{"text": "<text>", "alignment": "<left|center|right>", "reason": "<sentence>"}]. Do not include any markdown formatting, and escape any symbols in the source text. Make sure that your response can be run through a JSON parser and pass. The "text" attribute should be only enough text to identify the text that you found bias in. The "reason" attribute should be a short one-sentence summary of why that text is biased. Here is your data: `;

(function () {
    models.forEach((m, index) => {
        let container = $(`<div class="model"></div>`);
        let name = $(`<p class="model-name">${m.name}</p>`);
        let icon = $(
            `<span class="model-status" data-model="${index}"><svg xmlns="http://www.w3.org/2000/svg" height="1rem" viewBox="0 -960 960 960" width="1rem" fill="#FFFFFF"><path d="M164.67-160v-66.67H288l-15.33-12.66q-60-49.34-86.34-109Q160-408 160-477.33q0-107.67 63.83-192.84 63.84-85.16 167.5-115.83v69.33q-74 28-119.33 93.84-45.33 65.83-45.33 145.5 0 57 21.33 102.16 21.33 45.17 60 79.84L331.33-278v-115.33H398V-160H164.67Zm404.66-13.33v-70q74.67-28 119.34-93.84 44.66-65.83 44.66-145.5 0-47-21.33-94.16-21.33-47.17-58.67-84.5L630.67-682v115.33H564V-800h233.33v66.67h-124l15.34 14q56.33 53.66 83.83 115.5Q800-542 800-482.67 800-375 736.5-289.5 673-204 569.33-173.33Z"/></svg></span>`
        );

        container.append(name);
        container.append(icon);
        $(".models").append(container);
    });
})();

let modelStatusElements = [...$(".model-status")];

async function getResponses(data) {
    const prompt = systemInstructions + data.content;

    let responses = [];

    // Create an array of promises for each fetch request
    const fetchPromises = models.map(async (model, index) => {
        let modelStatus = $(`[data-model="${index}"]`);

        let errorStatus = $(`<svg xmlns="http://www.w3.org/2000/svg" height="1rem" viewBox="0 -960 960 960" width="1rem" fill="#ff6347"><path d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z"/></svg>`);
        let successStatus = $(`<svg xmlns="http://www.w3.org/2000/svg" height="1rem" viewBox="0 -960 960 960" width="1rem" fill="#4763ff"><path d="M382-240 154-468l57-57 171 171 367-367 57 57-424 424Z"/></svg>`);

        model.params.body = JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
        });

        // Perform the fetch and process the result
        try {
            const res = await fetch(model.url, model.params);
            modelStatus.css("animation", "none");
            modelStatus.empty();

            const body = await res.text();
            const content = model.getContent(body);

            responses.push({
                name: model.name,
                biases: JSON.parse(content)
            });

            modelStatus.append(content ? successStatus : errorStatus);
        } catch (e) {
            console.warn(`An error occurred while processing the response from ${model.name}: ${e}`);
            modelStatus.append(errorStatus);
        }
    });

    // Wait for all fetch requests to complete
    await Promise.all(fetchPromises);

    // Send the message after all requests are done
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.tabs.sendMessage(tabs[0].id, {
            action: "highlight-biases",
            data: JSON.stringify(responses),
        });
    });
}



$("#scan-btn").on("click", async (e) => {
    modelStatusElements.forEach((el) => (el.style.display = "block"));

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.tabs.sendMessage(
            tabs[0].id,
            { action: "get-raw-content" },
            getResponses
        );
    });
});

// chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
//     chrome.tabs.sendMessage(
//         tabs[0].id,
//         { action: "get-raw-content" },
//         async (response) => {
//             let prompt = `Identify any biases within the following text, and format them as an array of objects like so: [{"text": "...", "alignment": "left/right/center", "reason": "..."}, ...]. Do not format using markdown, and do not include any other text except the plaintext array in your response. Make sure to escape any characters that would invalidate JSON. Keep responses as short as possible, preferably one or two sentences. Here is your data: `;
//             const data = JSON.stringify({
//                 contents: [
//                     {
//                         parts: [
//                             {
//                                 text: prompt + response.content,
//                             },
//                         ],
//                     },
//                 ],
//             });

//             const res = await fetch(geminiURL, {
//                 method: "post",
//                 body: data,
//                 headers: {
//                     "Content-Type": "application/json",
//                 },
//             });

//             let biases = await res.text();
//             biases = JSON.parse(biases).candidates[0].content.parts[0].text;

//             try {
//                 JSON.parse(biases);
//                 updateModelStatus("gemini-status", 1);
//                 chrome.tabs.sendMessage(tabs[0].id, {
//                     action: "highlight-biases",
//                     data: biases,
//                 });
//             } catch (e) {
//                 updateModelStatus("gemini-status", 0);
//             }
//         }
//     );
// });
